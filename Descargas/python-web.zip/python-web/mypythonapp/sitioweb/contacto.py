# -*- coding: utf-8 -*-
def saludo():
    salida = "<p> Este es la pagina de contacto </p>"
    return salida
